<?php
/**
 * Configuração SMTP para envio de e-mails
 * 
 * IMPORTANTE: Este arquivo contém credenciais sensíveis.
 * NÃO commitar no Git. Adicionar ao .gitignore.
 */

// Configurações SMTP
define('SMTP_HOST', 'smtp.gmail.com'); // Alterar para seu servidor SMTP
define('SMTP_PORT', 587); // 587 para TLS, 465 para SSL
define('SMTP_SECURE', 'tls'); // 'tls' ou 'ssl'
define('SMTP_AUTH', true);
define('SMTP_USERNAME', 'seu-email@gmail.com'); // Alterar para seu e-mail
define('SMTP_PASSWORD', 'sua-senha-de-app'); // Alterar para sua senha de app

// Configurações do remetente
define('MAIL_FROM_EMAIL', 'noreply@swapsoft.com.br');
define('MAIL_FROM_NAME', 'Landing Page G4 Valley');

// Destinatário padrão
define('MAIL_TO_EMAIL', 'cleber@webajato.com.br');
define('MAIL_TO_NAME', 'Cleber');

// Configurações gerais
define('MAIL_CHARSET', 'UTF-8');
define('MAIL_DEBUG', 0); // 0 = desabilitado, 1 = client, 2 = client e server

/**
 * INSTRUÇÕES DE CONFIGURAÇÃO:
 * 
 * 1. GMAIL:
 *    - Ativar verificação em 2 etapas
 *    - Gerar senha de app: https://myaccount.google.com/apppasswords
 *    - Usar a senha de app gerada em SMTP_PASSWORD
 * 
 * 2. OUTLOOK/HOTMAIL:
 *    - SMTP_HOST: smtp-mail.outlook.com
 *    - SMTP_PORT: 587
 *    - SMTP_SECURE: tls
 * 
 * 3. YAHOO:
 *    - SMTP_HOST: smtp.mail.yahoo.com
 *    - SMTP_PORT: 587
 *    - SMTP_SECURE: tls
 * 
 * 4. SERVIDOR PRÓPRIO:
 *    - Configurar de acordo com seu provedor
 *    - Verificar se a porta está aberta no firewall
 * 
 * 5. SENDGRID:
 *    - SMTP_HOST: smtp.sendgrid.net
 *    - SMTP_PORT: 587
 *    - SMTP_USERNAME: apikey
 *    - SMTP_PASSWORD: sua-api-key-do-sendgrid
 * 
 * 6. MAILGUN:
 *    - SMTP_HOST: smtp.mailgun.org
 *    - SMTP_PORT: 587
 *    - SMTP_USERNAME: postmaster@seu-dominio.mailgun.org
 *    - SMTP_PASSWORD: sua-senha-mailgun
 */

