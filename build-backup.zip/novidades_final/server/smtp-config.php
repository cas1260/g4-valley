<?php
/**
 * Configuração SMTP para Envio de E-mails
 * 
 * ATENÇÃO: Este arquivo contém credenciais sensíveis.
 * Nunca commite este arquivo no Git!
 * 
 * Para produção: Configure estas variáveis com credenciais reais
 * Para desenvolvimento: Use credenciais de teste ou serviço como Mailtrap
 */

// ============================================================================
// CONFIGURAÇÕES DO SERVIDOR SMTP
// ============================================================================

define('SMTP_HOST', 'mail.swapsoft.com.br');
define('SMTP_PORT', 465); // 587 para TLS, 465 para SSL
define('SMTP_SECURE', 'ssl'); // 'tls' ou 'ssl'
define('SMTP_AUTH', true);
define('SMTP_USERNAME', 'cleber@swapsoft.com.br');
define('SMTP_PASSWORD', 'Lopasz99@@');

// ============================================================================
// CONFIGURAÇÕES DO REMETENTE
// ============================================================================

define('MAIL_FROM_EMAIL', 'cleber@swapsoft.com.br');
define('MAIL_FROM_NAME', 'Landing Page G4 Valley');

// ============================================================================
// DESTINATÁRIO PADRÃO
// ============================================================================

define('MAIL_TO_EMAIL', 'cleber@swapsoft.com.br');
define('MAIL_TO_NAME', 'Cleber Soares');

// ============================================================================
// CONFIGURAÇÕES GERAIS
// ============================================================================

define('MAIL_CHARSET', 'UTF-8');
define('MAIL_DEBUG', 0); // 0 = desabilitado, 1 = client, 2 = client e server

// ============================================================================
// VALIDAÇÃO DAS CONFIGURAÇÕES
// ============================================================================

if (!defined('SMTP_HOST') || empty(SMTP_HOST)) {
    error_log('SMTP_HOST não configurado em smtp-config.php');
}

if (!defined('SMTP_USERNAME') || empty(SMTP_USERNAME)) {
    error_log('SMTP_USERNAME não configurado em smtp-config.php');
}

if (!defined('SMTP_PASSWORD') || empty(SMTP_PASSWORD)) {
    error_log('SMTP_PASSWORD não configurado em smtp-config.php');
}

